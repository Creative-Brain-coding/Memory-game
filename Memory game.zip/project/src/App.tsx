import React, { useState } from 'react';
import LandingPage from './components/LandingPage';
import GameBoard from './components/GameBoard';

function App() {
  const [gameState, setGameState] = useState<'landing' | 'playing'>('landing');
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('easy');

  const handleStartGame = (selectedDifficulty: 'easy' | 'medium' | 'hard') => {
    setDifficulty(selectedDifficulty);
    setGameState('playing');
  };

  const handleBackToLanding = () => {
    setGameState('landing');
  };

  return (
    <div className="App">
      {gameState === 'landing' ? (
        <LandingPage onStartGame={handleStartGame} />
      ) : (
        <GameBoard difficulty={difficulty} onBack={handleBackToLanding} />
      )}
    </div>
  );
}

export default App;