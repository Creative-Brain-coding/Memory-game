import React from 'react';
import { Play, Trophy, Clock, Target } from 'lucide-react';

interface LandingPageProps {
  onStartGame: (difficulty: 'easy' | 'medium' | 'hard') => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onStartGame }) => {
  const difficulties = [
    {
      level: 'easy' as const,
      name: 'Easy',
      description: '12 cards (4x3)',
      icon: '🐱',
      color: 'from-green-400 to-blue-500'
    },
    {
      level: 'medium' as const,
      name: 'Medium',
      description: '16 cards (4x4)',
      icon: '🦁',
      color: 'from-yellow-400 to-orange-500'
    },
    {
      level: 'hard' as const,
      name: 'Hard',
      description: '24 cards (6x4)',
      icon: '🐅',
      color: 'from-red-400 to-pink-500'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-purple-50 to-orange-50 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-6xl font-bold bg-gradient-to-r from-teal-600 via-purple-600 to-orange-600 bg-clip-text text-transparent mb-4">
            Memory Jam
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
            Test your memory skills with this classic card matching game. 
            Flip cards, find pairs, and challenge yourself across different difficulty levels!
          </p>
        </div>

        {/* Game Features */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
            <div className="w-12 h-12 bg-teal-100 rounded-full flex items-center justify-center mb-4">
              <Clock className="w-6 h-6 text-teal-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Timed Challenge</h3>
            <p className="text-gray-600">Race against time to find all matching pairs and improve your best score.</p>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-4">
              <Target className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Attempt Tracking</h3>
            <p className="text-gray-600">Monitor your progress with detailed attempt counting and accuracy metrics.</p>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
            <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-4">
              <Trophy className="w-6 h-6 text-orange-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Multiple Levels</h3>
            <p className="text-gray-600">Choose from easy, medium, or hard difficulty levels to match your skill.</p>
          </div>
        </div>

        {/* Difficulty Selection */}
        <div className="bg-white rounded-3xl p-8 shadow-xl">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-8">Choose Your Challenge</h2>
          
          <div className="grid md:grid-cols-3 gap-6">
            {difficulties.map((diff) => (
              <button
                key={diff.level}
                onClick={() => onStartGame(diff.level)}
                className={`group relative overflow-hidden rounded-2xl p-8 text-white shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 bg-gradient-to-br ${diff.color}`}
              >
                <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity duration-300"></div>
                
                <div className="relative z-10 text-center">
                  <div className="text-4xl mb-4">{diff.icon}</div>
                  <h3 className="text-2xl font-bold mb-2">{diff.name}</h3>
                  <p className="text-lg opacity-90 mb-6">{diff.description}</p>
                  
                  <div className="inline-flex items-center space-x-2 bg-white bg-opacity-20 rounded-full px-4 py-2">
                    <Play className="w-4 h-4" />
                    <span className="font-medium">Start Game</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-12">
          <p className="text-gray-500">
            Created with ❤️ for memory game enthusiasts
          </p>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;