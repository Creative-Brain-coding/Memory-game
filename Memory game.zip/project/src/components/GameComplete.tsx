import React from 'react';
import { Trophy, Clock, Target, RotateCcw, ArrowLeft, Star } from 'lucide-react';

interface GameCompleteProps {
  difficulty: 'easy' | 'medium' | 'hard';
  attempts: number;
  time: number;
  onPlayAgain: () => void;
  onBack: () => void;
}

const GameComplete: React.FC<GameCompleteProps> = ({
  difficulty,
  attempts,
  time,
  onPlayAgain,
  onBack
}) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getPerformanceRating = () => {
    const difficultyMultiplier = difficulty === 'easy' ? 1 : difficulty === 'medium' ? 1.5 : 2;
    const timeScore = Math.max(0, 300 - time) * difficultyMultiplier;
    const attemptScore = Math.max(0, 50 - attempts) * difficultyMultiplier;
    const totalScore = timeScore + attemptScore;

    if (totalScore > 400) return { rating: 'Excellent!', stars: 3, color: 'text-yellow-500' };
    if (totalScore > 200) return { rating: 'Great!', stars: 2, color: 'text-orange-500' };
    return { rating: 'Good!', stars: 1, color: 'text-blue-500' };
  };

  const performance = getPerformanceRating();

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-purple-50 to-orange-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        {/* Celebration Header */}
        <div className="text-center mb-8">
          <div className="relative inline-block">
            <Trophy className="w-20 h-20 text-yellow-500 mx-auto mb-4 animate-bounce" />
            <div className="absolute -top-2 -right-2 w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center animate-pulse">
              <span className="text-white font-bold text-sm">!</span>
            </div>
          </div>
          
          <h1 className="text-5xl font-bold bg-gradient-to-r from-teal-600 via-purple-600 to-orange-600 bg-clip-text text-transparent mb-4">
            Congratulations!
          </h1>
          
          <p className="text-xl text-gray-600 mb-6">
            You've completed the {difficulty} level challenge!
          </p>

          {/* Performance Rating */}
          <div className="flex items-center justify-center space-x-2 mb-8">
            {[...Array(3)].map((_, i) => (
              <Star
                key={i}
                className={`w-8 h-8 ${
                  i < performance.stars
                    ? 'text-yellow-400 fill-current'
                    : 'text-gray-300'
                }`}
              />
            ))}
          </div>
          
          <h2 className={`text-3xl font-bold ${performance.color} mb-8`}>
            {performance.rating}
          </h2>
        </div>

        {/* Stats Card */}
        <div className="bg-white rounded-3xl p-8 shadow-xl mb-8">
          <h3 className="text-2xl font-bold text-center text-gray-800 mb-8">Your Performance</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="text-center p-6 bg-gradient-to-br from-teal-50 to-teal-100 rounded-2xl">
              <Clock className="w-12 h-12 text-teal-600 mx-auto mb-4" />
              <p className="text-sm text-gray-600 mb-2">Total Time</p>
              <p className="text-3xl font-bold text-teal-700">{formatTime(time)}</p>
            </div>

            <div className="text-center p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl">
              <Target className="w-12 h-12 text-purple-600 mx-auto mb-4" />
              <p className="text-sm text-gray-600 mb-2">Total Attempts</p>
              <p className="text-3xl font-bold text-purple-700">{attempts}</p>
            </div>
          </div>

          <div className="mt-6 p-6 bg-gradient-to-br from-orange-50 to-orange-100 rounded-2xl text-center">
            <p className="text-sm text-gray-600 mb-2">Difficulty Level</p>
            <p className="text-2xl font-bold text-orange-700 capitalize">{difficulty}</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4">
          <button
            onClick={onPlayAgain}
            className="flex-1 flex items-center justify-center space-x-3 bg-gradient-to-r from-teal-500 to-purple-600 text-white px-8 py-4 rounded-2xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
          >
            <RotateCcw className="w-6 h-6" />
            <span>Play Again</span>
          </button>

          <button
            onClick={onBack}
            className="flex-1 flex items-center justify-center space-x-3 bg-white text-gray-700 px-8 py-4 rounded-2xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border-2 border-gray-200 hover:border-gray-300"
          >
            <ArrowLeft className="w-6 h-6" />
            <span>Back to Menu</span>
          </button>
        </div>

        {/* Footer Message */}
        <div className="text-center mt-8">
          <p className="text-gray-500">
            Challenge yourself with a different difficulty level or try to beat your score!
          </p>
        </div>
      </div>
    </div>
  );
};

export default GameComplete;