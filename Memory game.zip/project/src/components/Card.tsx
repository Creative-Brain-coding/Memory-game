import React from 'react';

interface CardProps {
  card: {
    id: number;
    emoji: string;
    isFlipped: boolean;
    isMatched: boolean;
  };
  onClick: () => void;
}

const Card: React.FC<CardProps> = ({ card, onClick }) => {
  return (
    <div className="relative h-20 w-20 md:h-24 md:w-24 lg:h-28 lg:w-28 mx-auto">
      <div
        className={`absolute inset-0 w-full h-full transform-style-preserve-3d transition-transform duration-700 cursor-pointer ${
          card.isFlipped || card.isMatched ? 'rotate-y-180' : 'hover:scale-105'
        } ${card.isMatched ? 'cursor-default' : ''}`}
        onClick={onClick}
      >
        {/* Card Back */}
        <div className="absolute inset-0 w-full h-full backface-hidden bg-gradient-to-br from-teal-400 to-purple-500 rounded-xl shadow-lg flex items-center justify-center">
          <div className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
            <div className="w-4 h-4 bg-white bg-opacity-40 rounded-full"></div>
          </div>
        </div>

        {/* Card Front */}
        <div className={`absolute inset-0 w-full h-full backface-hidden rotate-y-180 rounded-xl shadow-lg flex items-center justify-center text-3xl md:text-4xl ${
          card.isMatched 
            ? 'bg-gradient-to-br from-green-300 to-emerald-400' 
            : 'bg-gradient-to-br from-white to-gray-50'
        }`}>
          {card.emoji}
        </div>
      </div>
    </div>
  );
};

export default Card;